package com.alison.catstretch;

import android.app.Activity;
import android.os.Bundle;
import android.os.IBinder;
import android.content.ComponentName;
import android.content.ServiceConnection;
import android.view.Gravity;
import android.view.Display;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private IProjectionService service;
    private TextView status;
    private final ServiceConnection connection = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName name, IBinder binder) {
            service = IProjectionService.Stub.asInterface(binder);
            status.setText("Shizuku conectado. Rotação atual: " + currentRotation() + ". Pronto para teste.");
        }
        @Override public void onServiceDisconnected(ComponentName name) { service = null; status.setText("Serviço desconectado."); }
    };
    private final Shizuku.OnRequestPermissionResultListener permissionListener = (requestCode, grantResult) -> {
        if (grantResult == android.content.pm.PackageManager.PERMISSION_GRANTED) bindService();
        else status.setText("Permissão Shizuku negada.");
    };
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        Shizuku.addRequestPermissionResultListener(permissionListener);
        LinearLayout layout = new LinearLayout(this); layout.setOrientation(LinearLayout.VERTICAL); layout.setGravity(Gravity.CENTER); layout.setPadding(28, 24, 28, 24); layout.setBackgroundColor(0xff080b10);
        TextView title = new TextView(this); title.setText("CAT STRETCH HELPER · TESTE"); title.setTextColor(0xff168bff); title.setTextSize(21); title.setGravity(Gravity.CENTER); layout.addView(title);
        status = new TextView(this); status.setText("Confere se o Shizuku está iniciado."); status.setTextColor(0xffeeeeee); status.setPadding(0, 20, 0, 20); layout.addView(status);
        Button connect = button("Conectar ao Shizuku"); connect.setOnClickListener(v -> connectShizuku()); layout.addView(connect);
        Button apply = button("TESTAR 1852 × 1080 → 2408 × 1080"); apply.setOnClickListener(v -> callApply()); layout.addView(apply);
        Button reset = button("Tentar restaurar projeção"); reset.setOnClickListener(v -> callReset()); layout.addView(reset);
        TextView warning = new TextView(this); warning.setText("Experimental para Samsung/Android 15. A rotação é lida do ecrã atual. O botão de restaurar é uma tentativa, não uma garantia. Tenha wm size reset à mão no Brevent; isso restaura apenas a resolução lógica."); warning.setTextColor(0xffbbbbbb); warning.setPadding(0, 18, 0, 0); layout.addView(warning);
        setContentView(layout);
        if (Shizuku.pingBinder()) connectShizuku(); else status.setText("Abra o Shizuku e inicie-o pela depuração sem fio.");
    }
    private int currentRotation() {
        Display display = getWindowManager().getDefaultDisplay();
        return display.getRotation(); // Surface.ROTATION_0..ROTATION_270
    }
    private Button button(String label) { Button b = new Button(this); b.setText(label); return b; }
    private void connectShizuku() {
        if (!Shizuku.pingBinder()) { status.setText("Shizuku não está ativo."); return; }
        if (Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED) { Shizuku.requestPermission(1001); return; }
        bindService();
    }
    private void bindService() {
        Shizuku.UserServiceArgs args = new Shizuku.UserServiceArgs(new ComponentName(this, ProjectionUserService.class)).daemon(false).processNameSuffix("projection").debuggable(BuildConfig.DEBUG);
        Shizuku.bindUserService(args, connection);
        status.setText("Solicitando serviço privilegiado…");
    }
    private void callApply() {
        try { if (service == null) { status.setText("Conecta ao Shizuku primeiro."); return; } status.setText(service.applyStretch(currentRotation(), 1852, 1080, 2408, 1080)); }
        catch (Exception e) { status.setText("Erro: " + e); }
    }
    private void callReset() {
        try { if (service == null) { status.setText("Conecta ao Shizuku primeiro."); return; } status.setText(service.resetProjection(currentRotation())); }
        catch (Exception e) { status.setText("Erro: " + e); }
    }
    @Override protected void onDestroy() { super.onDestroy(); Shizuku.removeRequestPermissionResultListener(permissionListener); try { Shizuku.unbindUserService(new Shizuku.UserServiceArgs(new ComponentName(this, ProjectionUserService.class)).daemon(false).processNameSuffix("projection").debuggable(BuildConfig.DEBUG), connection, true); } catch (Throwable ignored) {} }
}
