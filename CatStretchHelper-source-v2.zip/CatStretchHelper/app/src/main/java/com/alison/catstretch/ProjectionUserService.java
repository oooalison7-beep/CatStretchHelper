package com.alison.catstretch;

import android.graphics.Rect;
import android.os.IBinder;
import android.view.SurfaceControl;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

/** Shizuku UserService. Runs as shell UID when Shizuku is started via wireless debugging. */
public final class ProjectionUserService extends IProjectionService.Stub {
    @Override
    public String applyStretch(int rotation, int sourceWidth, int sourceHeight, int targetWidth, int targetHeight) {
        if (sourceWidth <= 0 || sourceHeight <= 0 || targetWidth <= 0 || targetHeight <= 0) {
            return "ERRO: dimensões inválidas";
        }
        return applyProjection(rotation, new Rect(0, 0, sourceWidth, sourceHeight),
                new Rect(0, 0, targetWidth, targetHeight));
    }

    @Override
    public String resetProjection(int rotation) {
        // Use only after `wm size reset`, when the A14's logical landscape frame is 2408x1080.
        Rect fullFrame = new Rect(0, 0, 2408, 1080);
        return applyProjection(rotation, fullFrame, fullFrame);
    }

    private String applyProjection(int rotation, Rect source, Rect destination) {
        Object transaction = null;
        try {
            Method idsMethod = SurfaceControl.class.getDeclaredMethod("getPhysicalDisplayIds");
            idsMethod.setAccessible(true);
            long[] ids = (long[]) idsMethod.invoke(null);
            if (ids == null || ids.length == 0) {
                return "ERRO: nenhum display físico encontrado";
            }

            Method tokenMethod = SurfaceControl.class.getDeclaredMethod("getPhysicalDisplayToken", long.class);
            tokenMethod.setAccessible(true);
            IBinder token = (IBinder) tokenMethod.invoke(null, ids[0]);
            if (token == null) {
                return "ERRO: token físico nulo; API pode não ser compatível com este Samsung";
            }

            Class<?> transactionClass = Class.forName("android.view.SurfaceControl$Transaction");
            Constructor<?> constructor = transactionClass.getDeclaredConstructor();
            constructor.setAccessible(true);
            transaction = constructor.newInstance();

            Method setProjection = transactionClass.getDeclaredMethod(
                    "setDisplayProjection", IBinder.class, int.class, Rect.class, Rect.class);
            setProjection.setAccessible(true);
            // Use the current rotation reported by the app; OEM display orientation may differ.
            if (rotation < 0 || rotation > 3) return "ERRO: rotação inválida (" + rotation + ")";
            setProjection.invoke(transaction, token, rotation, source, destination);

            Method apply = transactionClass.getDeclaredMethod("apply");
            apply.setAccessible(true);
            apply.invoke(transaction);
            return "OK: chamada de projeção enviada. Origem=" + source + "; destino=" + destination
                    + "; rotação=" + rotation + ". Confere visualmente; se não mudar, o sistema pode bloquear essa API.";
        } catch (Throwable error) {
            Throwable root = error;
            while (root.getCause() != null && root.getCause() != root) root = root.getCause();
            return "FALHOU: " + root.getClass().getSimpleName() + ": " + root.getMessage();
        } finally {
            if (transaction != null) {
                try {
                    Method close = transaction.getClass().getDeclaredMethod("close");
                    close.setAccessible(true);
                    close.invoke(transaction);
                } catch (Throwable ignored) {
                    // Some Android releases do not expose close() on this hidden class.
                }
            }
        }
    }
}
