package com.alison.catstretch;
interface IProjectionService {
    String applyStretch(int rotation, int sourceWidth, int sourceHeight, int targetWidth, int targetHeight);
    String resetProjection(int rotation);
}
