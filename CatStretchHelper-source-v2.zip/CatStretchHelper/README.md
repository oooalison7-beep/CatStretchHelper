# Cat Stretch Helper (experimental source project)

This is an **Android source project, not yet a compiled APK**. It attempts to call Android's hidden `SurfaceControl.Transaction.setDisplayProjection()` from a Shizuku UserService.

## Current test values
- Source rectangle: `0,0,1852,1080`
- Destination rectangle: `0,0,2408,1080`
- Rotation: read from the current display orientation when you press a button.

## Important limitations
- Experimental; Samsung Android 15 may block the hidden API or use a different display token API.
- The dimensions are specific to the observed Galaxy A14 landscape setup.
- This is not affiliated with Cat Resolution Pro.
- Keep `wm size reset` available in Brevent to restore logical resolution. The app's projection reset button is best-effort and is not guaranteed to restore the display if the OEM API behaves differently.
- Do not test while relying on the phone for an emergency; projection bugs can make the screen difficult to use.

## Build APK from a phone using GitHub Actions
1. Create a GitHub repository and upload the **contents** of this folder (including `.github/workflows/build-apk.yml`).
2. Open the repository's **Actions** tab and run **Build Cat Stretch Helper APK** (or push to `main`).
3. When the run finishes, open it and download the artifact named `CatStretchHelper-debug-apk`.
4. Extract the artifact ZIP; it contains `app-debug.apk`.
5. Install only if you understand this is experimental. Start Shizuku through wireless debugging, open the app, grant its Shizuku permission, connect, and test.

The workflow uses GitHub-hosted Android build tooling and does not require Gradle or the Android SDK to be installed on your phone.
